Program wymaga instalacji gtk+ w wersji 3.
Przed pierwszym uruchomieniem należy skompilować grę i/lub edytor plansz,
aby to zrobić w katalogu głównym programu trzeba wywołać polecenie.

make

Do kompilacji edytora i gry lub

make GAME

Do kompilacji samej gry lub

make EDITOR 

Do kompilacji samego edytora.
Aby usunąć wszystkie pliki pomocnicze do kompilacji oraz pliki wykonywalne należy uruchomić polecenie:

make clean